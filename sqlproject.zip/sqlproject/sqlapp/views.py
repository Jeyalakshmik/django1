from django.shortcuts import render, redirect, get_object_or_404
from .models import MyModel
from django.urls import reverse

def home(request):
    return render(request, 'home.html')

def create1(request):
    if request.method == 'POST':
        product_name = request.POST['product_name']
        price = request.POST['price']
        quantity = request.POST['quantity']
        description = request.POST['description']
        
        # Create the new product record
        MyModel.objects.create(
            product_name=product_name,
            price=price,
            quantity=quantity,
            description=description
        )
        
        # Redirect to success page with a success message as a query parameter
        success_message = "Record created successfully"
        return redirect(f"{reverse('success')}?message={success_message}")
    
    return render(request, 'create.html')

def read(request):
    records = MyModel.objects.all()
    return render(request, 'read.html', {'records': records})

def update(request, pk):
    product = get_object_or_404(MyModel, pk=pk)  # Get the specific product by pk
    if request.method == 'POST':
        product.product_name = request.POST['product_name']
        product.price = request.POST['price']
        product.quantity = request.POST['quantity']
        product.description = request.POST['description']
        product.save()  # Save the updated product details
        return redirect('readtab')  # Redirect to the read records page after updating

    return render(request, 'update.html', {'product': product})

def delete(request, pk):
    product = get_object_or_404(MyModel, pk=pk)
    product.delete()
    return redirect('readtab')

def success(request):
    success_message = request.GET.get('message', 'Operation successful')  # Default message if not provided
    return render(request, 'success.html', {'success_message': success_message})
